var usersController = require('../controllers/users-controller');
var cardsController = require('../controllers/cards-controller');

module.exports = {
    users: usersController,
    cards: cardsController
};